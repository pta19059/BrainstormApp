import React, { useState } from 'react';
import InputForm from './components/InputForm';
import OutputSection from './components/OutputSection';
import LoadingSpinner from './components/LoadingSpinner';

interface GenerationResult {
  brandNames: string[];
  slogans: string[];
  marketingStrategies: string[];
}

function App() {
  const [results, setResults] = useState<GenerationResult | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (userIdea: string) => {
    setLoading(true);
    setError('');
    setResults(null);

    try {
      const apiUrl = 'http://localhost:3001/api/generate';
      const startTime = new Date();
      const response = await fetch(apiUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ idea: userIdea }),
      });
      
      const endTime = new Date();
      const timeTaken = (endTime.getTime() - startTime.getTime()) / 1000;
      
      if (!response.ok) {
        let errorMessage;
        try {
          const errorData = await response.json();
          errorMessage = `API Error (${response.status}): ${JSON.stringify(errorData)}`;
        } catch (parseError) {
          try {
            const errorText = await response.text();
            errorMessage = `API Error (${response.status}): ${errorText}`;
          } catch (textError) {
            errorMessage = `API Error (${response.status}): Unable to read error details`;
          }
        }
        throw new Error(errorMessage);
      }
      
      const data = await response.json();
      
      if (data.rawResponse) {
        console.log("Raw response from OpenAI:", data.rawResponse);
      }
      
      const missingData = [];
      if (!data.brandNames?.length) missingData.push('brand names');
      if (!data.slogans?.length) missingData.push('slogans');
      if (!data.marketingStrategies?.length) missingData.push('strategies');
      
      if (missingData.length) {
        console.warn(`Missing data in response: ${missingData.join(', ')}`);
        console.log("Debug info:", data.debug);
      }

      setResults(data);
      setError(
        `✅ Generated in ${timeTaken.toFixed(1)}s: ${data.brandNames?.length || 0} names, ${data.slogans?.length || 0} slogans, ${data.marketingStrategies?.length || 0} strategies`
      );
      setTimeout(() => setError(""), 5000);
      
      setTimeout(() => {
        const resultsSection = document.getElementById('results-section');
        if (resultsSection) {
          resultsSection.scrollIntoView({ behavior: 'smooth' });
        }
      }, 100);
    } catch (err: any) {
      setError('Error: ' + err.message);
      console.error('Error details:', err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-100 via-pink-100 to-yellow-100 flex flex-col items-center p-4">
      <div className="w-full max-w-2xl bg-white/80 rounded-2xl shadow-xl p-8 mt-8">
        <h1 className="text-4xl font-extrabold text-center text-blue-700 mb-2 tracking-tight drop-shadow-lg">
          Business Brainstorming
        </h1>
        <p className="text-center text-lg text-gray-600 mb-8">
          Enter your idea and get AI-generated brand names, slogans, and marketing strategies!
        </p>
        <InputForm onSubmit={handleSubmit} loading={loading} />
        {loading && <LoadingSpinner />}
        {error && (
          <div className={`text-center font-semibold mt-4 ${error.startsWith('✅') ? 'text-green-600' : 'text-red-500'}`}>
            {error}
          </div>
        )}
        {results && (
          <div id="results-section" className="w-full mt-8 space-y-6">
            <OutputSection
              title="Brand Names"
              items={results.brandNames}
              accent="brand"
            />
            <OutputSection
              title="Advertising Slogans"
              items={results.slogans}
              accent="slogan"
            />
            <OutputSection
              title="Marketing Strategies"
              items={results.marketingStrategies}
              accent="marketing"
            />
          </div>
        )}
      </div>
      <footer className="mt-10 text-gray-400 text-sm">
        Powered by Azure OpenAI & React
      </footer>
    </div>
  );
}

export default App;
