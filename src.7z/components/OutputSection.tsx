import React from 'react';

interface OutputSectionProps {
  title: string;
  items: string[];
  accent: 'brand' | 'slogan' | 'marketing';
}

const OutputSection: React.FC<OutputSectionProps> = ({ title, items, accent }) => {
  const accentColors = {
    brand: 'bg-blue-100 border-blue-300 text-blue-800',
    slogan: 'bg-purple-100 border-purple-300 text-purple-800',
    marketing: 'bg-green-100 border-green-300 text-green-800',
  };

  return (
    <div className="bg-white/70 rounded-xl p-6 shadow-lg">
      <h2 className="text-2xl font-bold mb-4 text-gray-800">{title}</h2>
      <div className="space-y-3">
        {items.map((item, index) => (
          <div
            key={index}
            className={`p-4 rounded-lg border ${accentColors[accent]} transition-all hover:scale-[1.01]`}
          >
            {item}
          </div>
        ))}
      </div>
    </div>
  );
};

export default OutputSection;
