import React, { useState } from 'react';

interface InputFormProps {
  onSubmit: (idea: string) => void;
  loading: boolean;
}

const InputForm: React.FC<InputFormProps> = ({ onSubmit, loading }) => {
  const [idea, setIdea] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (idea.trim() && !loading) {
      onSubmit(idea.trim());
    }
  };

  return (
    <form onSubmit={handleSubmit} className="w-full">
      <div className="mb-4">
        <textarea
          className="w-full p-4 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none h-32"
          placeholder="Describe your business idea..."
          value={idea}
          onChange={(e) => setIdea(e.target.value)}
          disabled={loading}
          required
        />
      </div>
      <button
        type="submit"
        disabled={loading || !idea.trim()}
        className={`w-full py-3 px-6 text-white font-semibold rounded-lg shadow-md 
          ${loading || !idea.trim()
            ? 'bg-blue-300 cursor-not-allowed'
            : 'bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2'
          }`}
      >
        {loading ? 'Processing...' : 'Generate Ideas'}
      </button>
    </form>
  );
};

export default InputForm;
